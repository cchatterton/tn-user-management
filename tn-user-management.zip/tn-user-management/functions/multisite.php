<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/*
|--------------------------------------------------------------------------
| User Role Sync + Hidden Reference User
|--------------------------------------------------------------------------
|
| - administrator and subscriber are repaired if missing
| - user role matches administrator except for explicitly excluded capabilities
| - integration role has no capabilities and cannot authenticate
| - permission set menu model is based on a hidden reference user
| - reference user is ensured on activation and Sync Admin Rights
| - roles are no longer deleted
|
*/

/*
|--------------------------------------------------------------------------
| Integration Role Access Lock
|--------------------------------------------------------------------------
*/

add_filter( 'authenticate', 'tn731_umg_block_integration_authentication', 100, 3 );

function tn731_umg_block_integration_authentication( $user, $username, $password ) {

	if ( $user instanceof WP_User && in_array( 'integration', (array) $user->roles, true ) ) {
		return new WP_Error(
			'tn731_umg_integration_login_disabled',
			__( 'This integration account cannot be used to log in.', 'tn-user-management' )
		);
	}

	return $user;
}

add_action( 'init', 'tn731_umg_end_integration_user_sessions', -1 );

function tn731_umg_end_integration_user_sessions() {

	if ( ! is_user_logged_in() ) {
		return;
	}

	$user = wp_get_current_user();

	if ( in_array( 'integration', (array) $user->roles, true ) ) {
		wp_logout();
	}
}

add_filter( 'user_has_cap', 'tn731_umg_remove_integration_user_caps', 999, 4 );

function tn731_umg_remove_integration_user_caps( $allcaps, $caps, $args, $user ) {

	if ( $user instanceof WP_User && in_array( 'integration', (array) $user->roles, true ) ) {
		foreach ( $allcaps as $capability => $grant ) {
			$allcaps[ $capability ] = false;
		}
	}

	return $allcaps;
}

/*
|--------------------------------------------------------------------------
| Runtime capability inheritance
|--------------------------------------------------------------------------
*/

add_filter( 'user_has_cap', 'tn731_umg_grant_admin_caps_to_user_role', 20, 4 );

function tn731_umg_grant_admin_caps_to_user_role( $allcaps, $caps, $args, $user ) {

	if ( empty( $user ) || empty( $user->ID ) ) {
		return $allcaps;
	}

	$roles = isset( $user->roles ) ? (array) $user->roles : array();

	if ( in_array( 'administrator', $roles, true ) ) {
		return $allcaps;
	}

	if ( ! in_array( 'user', $roles, true ) ) {
		return $allcaps;
	}

	$admin_role = get_role( 'administrator' );

	if ( ! $admin_role ) {
		return $allcaps;
	}

	$excluded_capabilities = function_exists( 'tn731_umg_get_user_excluded_capabilities' )
		? tn731_umg_get_user_excluded_capabilities()
		: array();

	foreach ( (array) $admin_role->capabilities as $cap => $grant ) {
		if ( $grant && ! in_array( $cap, $excluded_capabilities, true ) ) {
			$allcaps[ $cap ] = true;
		}
	}

	return $allcaps;
}

/*
|--------------------------------------------------------------------------
| Hide reference user from normal Users UI
|--------------------------------------------------------------------------
*/

add_action( 'pre_get_users', 'tn731_umg_hide_reference_user_from_users_screen' );

function tn731_umg_hide_reference_user_from_users_screen( $query ) {

	if ( ! is_admin() ) {
		return;
	}

	if ( ! function_exists( 'get_current_screen' ) ) {
		return;
	}

	$screen = get_current_screen();

	if ( ! $screen || 'users' !== $screen->id ) {
		return;
	}

	$meta_query   = (array) $query->get( 'meta_query' );
	$meta_query[] = array(
		'relation' => 'OR',
		array(
			'key'     => 'tn731_umg_reference_user',
			'compare' => 'NOT EXISTS',
		),
		array(
			'key'     => 'tn731_umg_reference_user',
			'value'   => '1',
			'compare' => '!=',
		),
	);

	$query->set( 'meta_query', $meta_query );
}

/*
|--------------------------------------------------------------------------
| Reference user helpers
|--------------------------------------------------------------------------
*/

function tn731_umg_get_reference_user_login() {
	return 'tn731_umg_reference_user';
}

function tn731_umg_get_reference_user_email() {

	$blog_id = function_exists( 'get_current_blog_id' ) ? (int) get_current_blog_id() : 1;

	return 'tn731-umg-reference-user+' . $blog_id . '@local.invalid';
}

function tn731_umg_get_reference_user_id() {

	$users = get_users(
		array(
			'meta_key'    => 'tn731_umg_reference_user',
			'meta_value'  => '1',
			'number'      => 1,
			'count_total' => false,
			'fields'      => array( 'ID' ),
		)
	);

	if ( empty( $users ) ) {
		return 0;
	}

	return (int) $users[0]->ID;
}

function tn731_umg_ensure_reference_user_exists_current_site() {

	$existing_id = tn731_umg_get_reference_user_id();

	if ( $existing_id ) {
		$user = new WP_User( $existing_id );
		$user->set_role( 'user' );
		update_user_meta( $existing_id, 'tn731_umg_reference_user', '1' );
		update_user_meta( $existing_id, 'tn731_umg_hidden_user', '1' );
		clean_user_cache( $existing_id );
		return $existing_id;
	}

	$user_id = wp_insert_user(
		array(
			'user_login'   => tn731_umg_get_reference_user_login(),
			'user_pass'    => wp_generate_password( 32, true, true ),
			'user_email'   => tn731_umg_get_reference_user_email(),
			'display_name' => 'TN UMG Reference User',
			'role'         => 'user',
		)
	);

	if ( is_wp_error( $user_id ) ) {
		return 0;
	}

	update_user_meta( $user_id, 'tn731_umg_reference_user', '1' );
	update_user_meta( $user_id, 'tn731_umg_hidden_user', '1' );

	clean_user_cache( $user_id );

	return (int) $user_id;
}

function tn731_umg_ensure_reference_user_exists_all_sites() {

	if ( ! is_multisite() ) {
		tn731_umg_ensure_reference_user_exists_current_site();
		return;
	}

	$site_ids = tn731_umg_get_site_ids();

	if ( empty( $site_ids ) ) {
		return;
	}

	foreach ( $site_ids as $site_id ) {
		switch_to_blog( $site_id );
		tn731_umg_ensure_reference_user_exists_current_site();
		restore_current_blog();
	}
}

/*
|--------------------------------------------------------------------------
| Baseline Roles
|--------------------------------------------------------------------------
*/

function tn731_umg_ensure_baseline_roles( $network_wide = false ) {

	if ( is_multisite() && $network_wide ) {
		foreach ( tn731_umg_get_site_ids() as $site_id ) {
			switch_to_blog( $site_id );
			tn731_umg_ensure_baseline_roles_current_site();
			restore_current_blog();
		}
		return;
	}

	tn731_umg_ensure_baseline_roles_current_site();
}

function tn731_umg_ensure_baseline_roles_current_site() {

	if ( ! function_exists( 'populate_roles' ) ) {
		require_once ABSPATH . 'wp-admin/includes/schema.php';
	}

	if ( ! get_role( 'administrator' ) || ! get_role( 'subscriber' ) ) {
		populate_roles();
	}

	$integration_role = get_role( 'integration' );

	if ( ! $integration_role ) {
		add_role( 'integration', 'Integration', array() );
	} else {
		foreach ( array_keys( (array) $integration_role->capabilities ) as $capability ) {
			$integration_role->remove_cap( $capability );
		}
	}

	tn731_umg_sync_user_role_from_admin();
	update_option( 'tn731_umg_role_schema_version', TN731_UMG_ROLE_SCHEMA_VERSION, false );
}

add_action( 'init', 'tn731_umg_maybe_upgrade_roles', 1 );

function tn731_umg_maybe_upgrade_roles() {

	if ( TN731_UMG_ROLE_SCHEMA_VERSION === get_option( 'tn731_umg_role_schema_version' ) ) {
		return;
	}

	tn731_umg_ensure_baseline_roles_current_site();
}

/*
|--------------------------------------------------------------------------
| User Role Sync
|--------------------------------------------------------------------------
*/

function tn731_umg_sync_user_role_from_admin_current_site() {
	tn731_umg_ensure_baseline_roles_current_site();
	tn731_umg_ensure_reference_user_exists_current_site();
}

function tn731_umg_sync_user_role_from_admin_all_sites() {

	if ( ! is_multisite() ) {
		tn731_umg_sync_user_role_from_admin_current_site();
		return;
	}

	$site_ids = tn731_umg_get_site_ids();

	if ( empty( $site_ids ) ) {
		return;
	}

	foreach ( $site_ids as $site_id ) {
		switch_to_blog( $site_id );
		tn731_umg_ensure_baseline_roles_current_site();
		tn731_umg_ensure_reference_user_exists_current_site();
		restore_current_blog();
	}
}

function tn731_umg_sync_user_role_from_admin() {

	$admin_role = get_role( 'administrator' );

	if ( ! $admin_role ) {
		return;
	}

	$admin_caps            = (array) $admin_role->capabilities;
	$excluded_capabilities = function_exists( 'tn731_umg_get_user_excluded_capabilities' )
		? tn731_umg_get_user_excluded_capabilities()
		: array();

	foreach ( $excluded_capabilities as $capability ) {
		unset( $admin_caps[ $capability ] );
	}

	remove_role( 'user' );
	add_role( 'user', 'User', $admin_caps );

	global $wp_roles;

	if ( isset( $wp_roles ) && is_object( $wp_roles ) ) {
		$wp_roles->for_site();
	}
}

/**
 * Backward-friendly wrapper.
 */
function tn731_umg_create_user_role() {
	tn731_umg_ensure_baseline_roles_current_site();
}

/*
|--------------------------------------------------------------------------
| Site Helpers
|--------------------------------------------------------------------------
*/

function tn731_umg_get_site_ids() {

	if ( ! is_multisite() ) {
		return array();
	}

	return get_sites(
		array(
			'number' => 0,
			'fields' => 'ids',
		)
	);
}

/*
|--------------------------------------------------------------------------
| New Site Setup
|--------------------------------------------------------------------------
*/

add_action( 'wp_initialize_site', 'tn731_umg_on_initialize_site', 20, 1 );

function tn731_umg_on_initialize_site( $new_site ) {

	if ( empty( $new_site ) || empty( $new_site->blog_id ) ) {
		return;
	}

	switch_to_blog( (int) $new_site->blog_id );

	tn731_umg_ensure_baseline_roles_current_site();
	tn731_umg_ensure_reference_user_exists_current_site();

	restore_current_blog();
}

/*
|--------------------------------------------------------------------------
| Super Admin Sync
|--------------------------------------------------------------------------
*/

add_action( 'granted_super_admin', 'tn731_umg_sync_granted_super_admin_to_all_sites', 10, 1 );

/**
 * Add a newly granted Super Admin to every existing site as Administrator.
 *
 * @param int $user_id User ID granted Super Admin privileges.
 * @return bool Whether every site membership was synchronised.
 */
function tn731_umg_sync_granted_super_admin_to_all_sites( $user_id ) {
	$user_id = absint( $user_id );

	if ( ! is_multisite() || ! $user_id || ! get_userdata( $user_id ) || ! is_super_admin( $user_id ) ) {
		return false;
	}

	$success = true;

	foreach ( tn731_umg_get_site_ids() as $site_id ) {
		$site_id = (int) $site_id;

		if ( ! is_user_member_of_blog( $user_id, $site_id ) ) {
			$result = add_user_to_blog( $site_id, $user_id, 'administrator' );

			if ( is_wp_error( $result ) ) {
				$success = false;
			}

			continue;
		}

		switch_to_blog( $site_id );
		$user = new WP_User( $user_id );
		$user->set_role( 'administrator' );
		clean_user_cache( $user_id );
		restore_current_blog();
	}

	clean_user_cache( $user_id );

	return $success;
}

/**
 * Ensure the user performing activation cannot lose administrative access.
 *
 * On multisite, Super Admin is granted before site roles are changed, then the
 * user is explicitly made an Administrator on every existing site. On a
 * single site, the user is made an Administrator immediately.
 *
 * @param int $user_id Activating user ID.
 * @return bool Whether access could be enforced for a valid user.
 */
function tn731_umg_enforce_activating_user_access( $user_id ) {

	$user_id = absint( $user_id );

	if ( ! $user_id || ! get_userdata( $user_id ) ) {
		return false;
	}

	if ( ! is_multisite() ) {
		$user = new WP_User( $user_id );
		$user->set_role( 'administrator' );
		clean_user_cache( $user_id );
		return true;
	}

	if ( ! is_super_admin( $user_id ) ) {
		grant_super_admin( $user_id );
	}

	foreach ( tn731_umg_get_site_ids() as $site_id ) {
		$site_id = (int) $site_id;

		if ( ! is_user_member_of_blog( $user_id, $site_id ) ) {
			add_user_to_blog( $site_id, $user_id, 'administrator' );
			continue;
		}

		switch_to_blog( $site_id );
		$user = new WP_User( $user_id );
		$user->set_role( 'administrator' );
		clean_user_cache( $user_id );
		restore_current_blog();
	}

	clean_user_cache( $user_id );

	return is_super_admin( $user_id );
}

function tn731_umg_add_super_admins_to_all_sites() {

	if ( ! is_multisite() ) {
		return;
	}

	$super_admins = get_super_admins();

	if ( empty( $super_admins ) ) {
		return;
	}

	foreach ( $super_admins as $login ) {
		$user = get_user_by( 'login', $login );

		if ( ! $user ) {
			continue;
		}

		tn731_umg_sync_granted_super_admin_to_all_sites( $user->ID );
	}
}

/*
|--------------------------------------------------------------------------
| Role Migration
|--------------------------------------------------------------------------
*/

function tn731_umg_run_site_role_migration( $site_id ) {

	if ( ! is_multisite() ) {
		return;
	}

	switch_to_blog( $site_id );

	tn731_umg_ensure_baseline_roles_current_site();
	tn731_umg_ensure_reference_user_exists_current_site();

	$users = get_users(
		array(
			'blog_id' => $site_id,
			'fields'  => 'ids',
			'number'  => 999999,
		)
	);

	if ( ! empty( $users ) ) {
		foreach ( $users as $user_id ) {
			tn731_umg_normalise_user_role( $user_id );
		}
	}

	restore_current_blog();
}

function tn731_umg_run_single_site_role_migration() {

	tn731_umg_ensure_baseline_roles_current_site();
	tn731_umg_ensure_reference_user_exists_current_site();

	$users = get_users(
		array(
			'fields' => 'ids',
			'number' => 999999,
		)
	);

	if ( empty( $users ) ) {
		return;
	}

	foreach ( $users as $user_id ) {
		tn731_umg_normalise_user_role( $user_id );
	}
}

function tn731_umg_normalise_user_role( $user_id ) {

	$user = new WP_User( $user_id );

	if ( ! $user || empty( $user->ID ) ) {
		return;
	}

	if ( get_user_meta( $user_id, 'tn731_umg_reference_user', true ) === '1' ) {
		$user->set_role( 'user' );
		clean_user_cache( $user_id );
		return;
	}

	$roles = (array) $user->roles;

	if ( in_array( 'integration', $roles, true ) ) {
		$user->set_role( 'integration' );
		clean_user_cache( $user_id );
		return;
	}

	if ( is_multisite() && is_super_admin( $user_id ) ) {
		$user->set_role( 'administrator' );
		clean_user_cache( $user_id );
		return;
	}

	if ( in_array( 'administrator', $roles, true ) ) {
		$user->set_role( 'administrator' );
		clean_user_cache( $user_id );
		return;
	}

	if ( in_array( 'subscriber', $roles, true ) ) {
		$user->set_role( 'subscriber' );
		clean_user_cache( $user_id );
		return;
	}

	$user->set_role( 'user' );
	clean_user_cache( $user_id );
}

/*
|--------------------------------------------------------------------------
| Role Cleanup
|--------------------------------------------------------------------------
|
| Intentionally disabled.
| We no longer delete existing roles.
|
*/

function tn731_umg_remove_non_baseline_roles() {
	return;
}

function tn731_umg_assign_no_role_users_to_subscriber_current_site() {

	$users = get_users(
		array(
			'fields' => 'ids',
			'number' => 999999,
		)
	);

	if ( empty( $users ) ) {
		return;
	}

	foreach ( $users as $user_id ) {

		if ( get_user_meta( $user_id, 'tn731_umg_reference_user', true ) === '1' ) {
			continue;
		}

		if ( is_multisite() && is_super_admin( $user_id ) ) {
			continue;
		}

		$wp_user = new WP_User( $user_id );
		$roles   = (array) $wp_user->roles;

		if ( empty( $roles ) ) {
			$wp_user->set_role( 'subscriber' );
			clean_user_cache( $user_id );
		}
	}
}

function tn731_umg_assign_no_role_users_to_subscriber_all_sites() {

	if ( ! is_multisite() ) {
		tn731_umg_assign_no_role_users_to_subscriber_current_site();
		return;
	}

	foreach ( tn731_umg_get_site_ids() as $site_id ) {
		switch_to_blog( $site_id );
		tn731_umg_assign_no_role_users_to_subscriber_current_site();
		restore_current_blog();
	}
}
